# insertmap
 Map insertion sites from wgs or lam-pcr
